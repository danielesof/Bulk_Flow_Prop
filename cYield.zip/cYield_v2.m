classdef app2 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                    matlab.ui.Figure
        GridLayout                  matlab.ui.container.GridLayout
        InputdataPanel              matlab.ui.container.Panel
        UITable                     matlab.ui.control.Table
        ShearDataLabel              matlab.ui.control.Label
        PreShearLABEL               matlab.ui.control.Label
        SigmaPreShEditFieldLabel    matlab.ui.control.Label
        SigmaPre                    matlab.ui.control.NumericEditField
        TauPreShEditFieldLabel      matlab.ui.control.Label
        TauPre                      matlab.ui.control.NumericEditField
        Button                      matlab.ui.control.Button
        Button_2                    matlab.ui.control.Button
        LINEARYLButton              matlab.ui.control.Button
        WARRENSPRINGButton          matlab.ui.control.Button
        COMPAREButton               matlab.ui.control.Button
        DiagramPanel                matlab.ui.container.Panel
        UIAxes                      matlab.ui.control.UIAxes
        OutputDataPanel             matlab.ui.container.Panel
        UITable2                    matlab.ui.control.Table
        TabGroup                    matlab.ui.container.TabGroup
        ModelfittingTab             matlab.ui.container.Tab
        UITable3                    matlab.ui.control.Table
        ParametersdataTab           matlab.ui.container.Tab
        CohesionPaEditFieldLabel    matlab.ui.control.Label
        CohesionLIN                 matlab.ui.control.NumericEditField
        CohesionLINmin              matlab.ui.control.NumericEditField
        CohesionLINmax              matlab.ui.control.NumericEditField
        TensStrPaEditFieldLabel     matlab.ui.control.Label
        TensStrLIN                  matlab.ui.control.NumericEditField
        TensStrLINmin               matlab.ui.control.NumericEditField
        TensStrLINmax               matlab.ui.control.NumericEditField
        CohesionPaEditField_2Label  matlab.ui.control.Label
        CohesionWS                  matlab.ui.control.NumericEditField
        CohesionWSmin               matlab.ui.control.NumericEditField
        CohesionWSmax               matlab.ui.control.NumericEditField
        TensStrPaEditField_2Label   matlab.ui.control.Label
        TensStrWS                   matlab.ui.control.NumericEditField
        TensStrWSmin                matlab.ui.control.NumericEditField
        TensStrWSmax                matlab.ui.control.NumericEditField
        LinearYLLabel               matlab.ui.control.Label
        WarrenSpringYLLabel         matlab.ui.control.Label
        ValueLabel                  matlab.ui.control.Label
        MinLabel                    matlab.ui.control.Label
        MaxLabel                    matlab.ui.control.Label
        RESETRESULTSButton          matlab.ui.control.Button
        REBOOTButton                matlab.ui.control.Button
    end

    
    methods (Access = private)
        
        function results = func(app)
            
        end
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            nROW=1;
            app.UITable.Data = zeros(nROW,numel(app.UITable.ColumnName));
            app.UITable.ColumnEditable = true(1,2); % columns editable
%             sQ=[570 1123 1672 2224]'; %testing purposes
%             tQ =[1530 2060 2433 2773]';
%             DataQ = table(sQ, tQ);
%             app.UITable.Data =DataQ;
            
            nROW2=8;
            app.UITable2.Data = zeros(nROW2,numel(app.UITable2.ColumnName));
            app.UITable2.ColumnEditable = true(1,2); % columns editable
            
            nROW3=3;
            app.UITable3.Data = zeros(nROW3,numel(app.UITable3.ColumnName));
            app.UITable3.ColumnEditable = true(1,2); % columns editable
            
            
        end

        % Button pushed function: LINEARYLButton
        function LINEARYLButtonPushed(app, event)
            s_pre = app.SigmaPre.Value;
            t_pre = app.TauPre.Value;
            %             tabData=app.UITable.Data; % fast testing purposes
            %             sigma=table2array(tabData(:,1));%sigma set from UITable
            %             tau=table2array(tabData(:,2));%tau set from UITable
            
            data = app.UITable.Data;
            sigma = data(:,1);
            tau = data(:,2);
            
            LYLmodelfit = fittype( @(C, st, x) C+(C/st)*x);
            fitresult_in = fit(sigma,tau,LYLmodelfit,'StartPoint', [1, -1]);
            Coeff = coeffvalues(fitresult_in);
            C_in=Coeff(1);
            sigma_t_in=Coeff(2);
            
            t_pre_YL = C_in+C_in/sigma_t_in*s_pre;
            
            if t_pre < t_pre_YL %CHECK ON THE POSITION OF THE PRE-SHEAR POINT
                C=C_in,
                sigma_t=sigma_t_in;
                ci = confint(fitresult_in,0.95);
            else
                sigma_new=[sigma,s_pre];
                tau_new=[tau,t_pre];
                fitresult= fit(sigma_new,tau_new,LYLmodelfit,'StartPoint', [1, -1]);
                [Coeff]=coeffvalues(fitresult);
                C=Coeff(1);
                sigma_t=Coeff(2);
                ci = confint(fitresult,0.95);
            end
            
            P(1)=C/sigma_t;
            P(2)=C;
            
            [M, R, s1, s2, phie] = Mohr_circle_s1_LYL(P,sigma,s_pre,t_pre);
            Coeff_fc=[1, -4*C*P(1), -4*C^2];
            fc_sol=roots(Coeff_fc);
            fc = max(fc_sol);
            
            % plot LYL equation
            sigma_LYL(1)=-sigma_t;
            n=5000;
            p=(s1+sigma_t)/(n-1);
            for i=2:n
                sigma_LYL(i)=sigma_LYL(1)+i*p;
            end
            
            for i=1:n
                tau_LYL(i)=P(1)*sigma_LYL(i)+P(2);
            end
            
            for i=1:length(sigma)
                tau_mse(i)=P(1)*sigma(i)+P(2);
            end
            tau_mod=tau_mse';
            [Rsquare, RMSE] = rsquare(tau,tau_mod);
            Pearson_matrix=corrcoef(tau,tau_mod);
            Pearson=Pearson_matrix(1,2);
            
            %plot Mohr Circle s1
            sigma_MC_s1(1)=s2;
            ns1=5000;
            ps1=(s1-s2)/(ns1-1);
            for i=2:ns1
                sigma_MC_s1(i)=s2+i*ps1;
            end
            
            for i=1:ns1
                tau_MC_s1(i)=sqrt(R^2-(sigma_MC_s1(i)-M)^2);
            end
            
            %plot Mohr Circle fc
            sigma_MC_fc(1)=0;
            nfc=5000;
            pfc=(fc)/(nfc-1);
            for i=2:nfc
                sigma_MC_fc(i)=i*pfc;
            end
            
            for i=1:nfc
                tau_MC_fc(i)=sqrt((fc-sigma_MC_fc(i))*sigma_MC_fc(i));
            end
            
            tau_max=max(tau_LYL);
            nmax=5000;
            pmax=tau_max/(nmax-1);
            tau_y(1)=0;
            for i=2:nmax
                tau_y(i)=i*pmax;
            end
            sigma_x0=zeros(1,nmax);
            
            plot(app.UIAxes,sigma_LYL,tau_LYL,'r-')
            hold(app.UIAxes)
            plot(app.UIAxes,sigma,tau,'k.','MarkerSize',15);
            plot(app.UIAxes,s_pre,t_pre,'k^');
            plot(app.UIAxes,sigma_x0,tau_y,'k'); %Y axis at x=0
            plot(app.UIAxes,sigma_MC_s1,tau_MC_s1,'r--');
            plot(app.UIAxes,sigma_MC_fc,tau_MC_fc,'r--');
            hold(app.UIAxes, 'off')
            
            col=1;
            Parameters_Matrix(1,col) = round(s1);
            Parameters_Matrix(2,col) = round(R);
            Parameters_Matrix(3,col) = round(M);
            Parameters_Matrix(4,col) = round(fc);
            Parameters_Matrix(5,col) = round(C);
            Parameters_Matrix(6,col) = round(sigma_t);
            Parameters_Matrix(7,col) = 1;
            phi=(180/pi)*phie;
            Parameters_Matrix(8,col) = round(phi);
            Parameters_Matrix(:,2)=zeros(8,1);
            
            datastat_matrix(1,col)=round(Rsquare,2);
            datastat_matrix(2,col)=round(RMSE,2);
            datastat_matrix(3,col)=round(Pearson,2);
            datastat_matrix(:,2)=zeros(3,1);
            
            app.UITable2.Data=Parameters_Matrix;
            app.UITable3.Data=datastat_matrix;
            
            app.CohesionLIN.Value=round(C);
            app.CohesionLINmin.Value=round(ci(1,1));
            app.CohesionLINmax.Value=round(ci(2,1));
            app.TensStrLIN.Value=round(sigma_t);
            app.TensStrLINmin.Value=round(ci(1,2));
            app.TensStrLINmax.Value=round(ci(2,2));
        end

        % Button pushed function: Button
        function ButtonPushed(app, event)
            app.UITable.Data(end+1,:) = 0; % Add Row of zeros
        end

        % Button pushed function: Button_2
        function Button_2Pushed(app, event)
            app.UITable.Data(end,:) = []; % Delete Row
        end

        % Button pushed function: RESETRESULTSButton
        function RESETRESULTSButtonPushed(app, event)
            nROW2=8;
            app.UITable2.Data = zeros(nROW2,numel(app.UITable2.ColumnName));
            app.UITable2.ColumnEditable = true(1,2); % columns editable
            
            nROW3=3;
            app.UITable3.Data = zeros(nROW3,numel(app.UITable3.ColumnName));
            app.UITable3.ColumnEditable = true(1,2); % columns editable
            
            app.CohesionLIN.Value=0;
            app.CohesionLINmin.Value=0;
            app.CohesionLINmax.Value=0;
            app.TensStrLIN.Value=0;
            app.TensStrLINmin.Value=0;
            app.TensStrLINmax.Value=0;
            
            plot(app.UIAxes,0,0)
            
        end

        % Button pushed function: WARRENSPRINGButton
        function WARRENSPRINGButtonPushed(app, event)
            
            s_pre = app.SigmaPre.Value;
            t_pre = app.TauPre.Value;
            %             tabData=app.UITable.Data; %fast testing purposes
            %             sigma=table2array(tabData(:,1));%sigma set from UITable
            %             tau=table2array(tabData(:,2));%tau set from UITable
            
            data = app.UITable.Data;
            sigma = data(:,1);
            tau = data(:,2);
            
            LYLmodelfit = fittype( @(C, st, x) C+(C/st)*x);
            fitresult_in = fit(sigma,tau,LYLmodelfit,'StartPoint', [1, -1]);
            Coeff = coeffvalues(fitresult_in);
            C=Coeff(1);
            sigma_t=Coeff(2);
            
            YL_lin=[C, sigma_t, 1]; %starting values (Linear Yield locus) [C sigma_t n]
            OPTIONS = optimset('MaxFunEvals',100000);
            
            [WS_par_in,RMSE_in]=fmincon(@(WS_par)FUN_obj_tau(WS_par,sigma,tau),YL_lin,[],[],[],[],[0 0 1],[Inf Inf 2],[],OPTIONS);
            
            t_pre_WS = WS_par_in(1)*(1+s_pre/WS_par_in(2))^(1/WS_par_in(3));
            
            if t_pre < t_pre_WS %CHECK ON THE POSITION OF THE PRE-SHEAR POINT
                WS_par = WS_par_in;
                RMSE = RMSE_in;
            else
                [WS_par,RMSE] = fmincon(@(WS_par)Fun_obj_tau_pre(WS_par,sigma,tau,s_pre,t_pre),YL_lin,[],[],[],[],[0 0 1],[Inf Inf 2],[],OPTIONS);
            end
            
            [M, R, s1, s2, phie] = Mohr_circle_s1(WS_par,sigma,s_pre,t_pre);
            [fc] = Mohr_circle_fc_iter(WS_par,s2);
            
            % plot WS equation
            sigma_WS(1)=-WS_par(2);
            n=5000;
            p=(s1+WS_par(2))/(n-1);
            for i=2:n
                sigma_WS(i)=sigma_WS(1)+i*p;
            end
            
            for i=1:n
                tau_WS(i)=WS_par(1)*(1+sigma_WS(i)/WS_par(2))^(1/WS_par(3));
            end
            
            for i=1:length(sigma)
                tau_mse(i)=WS_par(1)*(1+sigma(i)/WS_par(2))^(1/WS_par(3));
            end
            tau_mod=tau_mse';
            [Rsquare, RMSE_2] = rsquare(tau,tau_mod);
            Pearson_matrix=corrcoef(tau,tau_mod);
            Pearson=Pearson_matrix(1,2);
            
            %plot Mohr Circle s1
            sigma_MC_s1(1)=s2;
            ns1=5000;
            ps1=(s1-s2)/(ns1-1);
            for i=2:ns1
                sigma_MC_s1(i)=s2+i*ps1;
            end
            
            for i=1:ns1
                tau_MC_s1(i)=sqrt(R^2-(sigma_MC_s1(i)-M)^2);
            end
            
            %plot Mohr Circle fc
            sigma_MC_fc(1)=0;
            nfc=5000;
            pfc=(fc)/(nfc-1);
            for i=2:nfc
                sigma_MC_fc(i)=i*pfc;
            end
            
            for i=1:nfc
                tau_MC_fc(i)=sqrt((fc-sigma_MC_fc(i))*sigma_MC_fc(i));
            end
            
            tau_max=max(tau_WS);
            nmax=5000;
            pmax=tau_max/(nmax-1);
            tau_y(1)=0;
            for i=2:nmax
                tau_y(i)=i*pmax;
            end
            sigma_x0=zeros(1,nmax);
            
            plot(app.UIAxes,sigma_WS,tau_WS,'b');
            hold(app.UIAxes);
            plot(app.UIAxes,sigma,tau,'k.','MarkerSize',15)
            plot(app.UIAxes,s_pre,t_pre,'k^');
            plot(app.UIAxes,sigma_x0,tau_y,'k'); %Y axis
            plot(app.UIAxes,sigma_MC_s1,tau_MC_s1,'b--');
            plot(app.UIAxes,sigma_MC_fc,tau_MC_fc,'b--');
            hold(app.UIAxes, 'off')
            
            col=2;
            Parameters_Matrix(1,col) = round(s1);
            Parameters_Matrix(2,col) = round(R);
            Parameters_Matrix(3,col) = round(M);
            Parameters_Matrix(4,col) = round(fc);
            Parameters_Matrix(5,col) = round(WS_par(1));
            Parameters_Matrix(6,col) = round(WS_par(2));
            Parameters_Matrix(7,col) = WS_par(3);
            phi=(180/pi)*phie;
            Parameters_Matrix(8,col) = round(phi);
            Parameters_Matrix(:,1)=zeros(8,1);
            
            datastat_matrix(1,col)=round(Rsquare,2);
            datastat_matrix(2,col)=round(RMSE,2);
            datastat_matrix(3,col)=round(Pearson,2);
            datastat_matrix(:,1)=zeros(3,1);
            
            app.UITable2.Data=Parameters_Matrix;
            app.UITable3.Data=datastat_matrix;
        end

        % Button pushed function: COMPAREButton
        function COMPAREButtonPushed(app, event)
            s_pre = app.SigmaPre.Value;
            t_pre = app.TauPre.Value;
            %             tabData=app.UITable.Data; %fast testing purposes
            %             sigma=table2array(tabData(:,1));%sigma set from UITable
            %             tau=table2array(tabData(:,2));%tau set from UITable
            
            data = app.UITable.Data;
            sigma = data(:,1);
            tau = data(:,2);
            
            LYLmodelfit = fittype( @(C, st, x) C+(C/st)*x);
            fitresult_in = fit(sigma,tau,LYLmodelfit,'StartPoint', [1, -1]);
            Coeff = coeffvalues(fitresult_in);
            C_in=Coeff(1);
            sigma_t_in=Coeff(2);
            
            t_pre_YL = C_in+C_in/sigma_t_in*s_pre;
            
            if t_pre < t_pre_YL %CHECK ON THE POSITION OF THE PRE-SHEAR POINT
                C_LYL=C_in,
                sigma_t_LYL=sigma_t_in;
                ci = confint(fitresult_in,0.95);
            else
                sigma_new=[sigma,s_pre];
                tau_new=[tau,t_pre];
                fitresult= fit(sigma_new,tau_new,LYLmodelfit,'StartPoint', [1, -1]);
                [Coeff]=coeffvalues(fitresult);
                C_LYL=Coeff(1);
                sigma_t_LYL=Coeff(2);
                ci = confint(fitresult,0.95);
            end
            
            P(1)=C_LYL/sigma_t_LYL;
            P(2)=C_LYL;
            
            [M_LYL, R_LYL, s1_LYL, s2_LYL, phie_LYL] = Mohr_circle_s1_LYL(P,sigma,s_pre,t_pre);
            Coeff_fc=[1, -4*C_LYL*P(1), -4*C_LYL^2];
            fc_sol=roots(Coeff_fc);
            fc_LYL = max(fc_sol);
            
            % plot LYL equation
            sigma_LYL(1)=-sigma_t_LYL;
            n=5000;
            p=(s1_LYL+sigma_t_LYL)/(n-1);
            for i=2:n
                sigma_LYL(i)=sigma_LYL(1)+i*p;
            end
            
            for i=1:n
                tau_LYL(i)=P(1)*sigma_LYL(i)+P(2);
            end
            
            for i=1:length(sigma)
                tau_mse_LYL(i)=P(1)*sigma(i)+P(2);
            end
            
            tau_mod_LYL=tau_mse_LYL';
            [Rsquare_LYL, RMSE_LYL] = rsquare(tau,tau_mod_LYL);
            Pearson_matrix_LYL=corrcoef(tau,tau_mod_LYL);
            Pearson_LYL=Pearson_matrix_LYL(1,2);
            
            %plot Mohr Circle s1
            sigma_MC_s1_LYL(1)=s2_LYL;
            ns1=5000;
            ps1=(s1_LYL-s2_LYL)/(ns1-1);
            for i=2:ns1
                sigma_MC_s1_LYL(i)=s2_LYL+i*ps1;
            end
            
            for i=1:ns1
                tau_MC_s1_LYL(i)=sqrt(R_LYL^2-(sigma_MC_s1_LYL(i)-M_LYL)^2);
            end
            
            %plot Mohr Circle fc
            sigma_MC_fc_LYL(1)=0;
            nfc=5000;
            pfc=(fc_LYL)/(nfc-1);
            for i=2:nfc
                sigma_MC_fc_LYL(i)=i*pfc;
            end
            
            for i=1:nfc
                tau_MC_fc_LYL(i)=sqrt((fc_LYL-sigma_MC_fc_LYL(i))*sigma_MC_fc_LYL(i));
            end
            
            tau_max_LYL=max(tau_LYL);
            nmax=5000;
            pmax=tau_max_LYL/(nmax-1);
            tau_y_LYL(1)=0;
            for i=2:nmax
                tau_y_LYL(i)=i*pmax;
            end
            sigma_x0=zeros(1,nmax);
            
            
            
            col=1;
            Parameters_Matrix(1,col) = round(s1_LYL);
            Parameters_Matrix(2,col) = round(R_LYL);
            Parameters_Matrix(3,col) = round(M_LYL);
            Parameters_Matrix(4,col) = round(fc_LYL);
            Parameters_Matrix(5,col) = round(C_LYL);
            Parameters_Matrix(6,col) = round(sigma_t_LYL);
            Parameters_Matrix(7,col) = 1.00;
            phi_LYL=(180/pi)*phie_LYL;
            Parameters_Matrix(8,col) = round(phi_LYL);
            Parameters_Matrix(:,2)=zeros(8,1);
            
            datastat_matrix(1,col)=round(Rsquare_LYL,2);
            datastat_matrix(2,col)=round(RMSE_LYL,2);
            datastat_matrix(3,col)=round(Pearson_LYL,2);
            
            app.CohesionLIN.Value=round(C_LYL);
            app.CohesionLINmin.Value=round(ci(1,1));
            app.CohesionLINmax.Value=round(ci(2,1));
            app.TensStrLIN.Value=round(sigma_t_LYL);
            app.TensStrLINmin.Value=round(ci(1,2));
            app.TensStrLINmax.Value=round(ci(2,2));
            
            
            %********** Warren-spring Eqn.***************
            
            YL_lin=[P(1), P(2)/P(1), 1]; %starting values (Linear Yield locus) [C sigma_t n]
            OPTIONS = optimset('MaxFunEvals',100000);
            
            [WS_par_in,RMSE_in]=fmincon(@(WS_par)FUN_obj_tau(WS_par,sigma,tau),YL_lin,[],[],[],[],[0 0 1],[Inf Inf 2],[],OPTIONS);
            
            t_pre_WS = WS_par_in(1)*(1+s_pre/WS_par_in(2))^(1/WS_par_in(3));
            
            if t_pre < t_pre_WS
                WS_par = WS_par_in;
                RMSE=RMSE_in;
            else
                [WS_par,RMSE] = fmincon(@(WS_par)Fun_obj_tau_pre(WS_par,sigma,tau,s_pre,t_pre),YL_lin,[],[],[],[],[0 0 1],[Inf Inf 2],[],OPTIONS);
            end
            
            [M, R, s1, s2, phie] = Mohr_circle_s1(WS_par,sigma,s_pre,t_pre);
            [fc] = Mohr_circle_fc_iter(WS_par,s2);
            
            
            % plot WS equation
            sigma_WS(1)=-WS_par(2);
            n=5000;
            p=(s1+WS_par(2))/(n-1);
            for i=2:n
                sigma_WS(i)=sigma_WS(1)+i*p;
            end
            
            for i=1:n
                tau_WS(i)=WS_par(1)*(1+sigma_WS(i)/WS_par(2))^(1/WS_par(3));
            end
            
            for i=1:length(sigma)
                tau_mse(i)=WS_par(1)*(1+sigma(i)/WS_par(2))^(1/WS_par(3));
            end
            
            tau_mod=tau_mse';
            
            [Rsquare, RMSE_2] = rsquare(tau,tau_mod);
            Pearson_matrix=corrcoef(tau,tau_mod);
            Pearson=Pearson_matrix(1,2);
            
            %plot Mohr Circle s1
            sigma_MC_s1(1)=s2;
            ns1=5000;
            ps1=(s1-s2)/(ns1-1);
            for i=2:ns1
                sigma_MC_s1(i)=s2+i*ps1;
            end
            
            for i=1:ns1
                tau_MC_s1(i)=sqrt(R^2-(sigma_MC_s1(i)-M)^2);
            end
            
            %plot Mohr Circle fc
            sigma_MC_fc(1)=0;
            nfc=5000;
            pfc=(fc)/(nfc-1);
            for i=2:nfc
                sigma_MC_fc(i)=i*pfc;
            end
            
            for i=1:nfc
                tau_MC_fc(i)=sqrt((fc-sigma_MC_fc(i))*sigma_MC_fc(i));
            end
            
            tau_max=max(tau_WS);
            nmax=5000;
            pmax=tau_max/(nmax-1);
            tau_y(1)=0;
            for i=2:nmax
                tau_y(i)=i*pmax;
            end
            sigma_x0=zeros(1,nmax);
            
            
            col=2;
            Parameters_Matrix(1,col) = round(s1);
            Parameters_Matrix(2,col) = round(R);
            Parameters_Matrix(3,col) = round(M);
            Parameters_Matrix(4,col) = round(fc);
            Parameters_Matrix(5,col) = round(WS_par(1));
            Parameters_Matrix(6,col) = round(WS_par(2));
            Parameters_Matrix(7,col) = round(WS_par(3),2);
            phi=(180/pi)*phie;
            Parameters_Matrix(8,col) = round(phi);
            
            datastat_matrix(1,col)=round(Rsquare,2);
            datastat_matrix(2,col)=round(RMSE,2);
            datastat_matrix(3,col)=round(Pearson,2);
            
            plot(app.UIAxes,sigma_LYL,tau_LYL,'r')
            hold(app.UIAxes)
            plot(app.UIAxes,sigma_x0,tau_y_LYL,'k'); %asse y
            plot(app.UIAxes,sigma_MC_s1_LYL,tau_MC_s1_LYL,'r--');
            plot(app.UIAxes,sigma_MC_fc_LYL,tau_MC_fc_LYL,'r--');
            plot(app.UIAxes,sigma_WS,tau_WS,'b');
            plot(app.UIAxes,sigma,tau,'k.','MarkerSize',15)
            plot(app.UIAxes,s_pre,t_pre,'k^');
            plot(app.UIAxes,sigma_MC_s1,tau_MC_s1,'b--');
            plot(app.UIAxes,sigma_MC_fc,tau_MC_fc,'b--');
            hold(app.UIAxes, 'off')

           
            % Table output
            app.UITable2.Data=Parameters_Matrix;
            app.UITable3.Data=datastat_matrix;
        end

        % Button pushed function: REBOOTButton
        function REBOOTButtonPushed(app, event)
            startupFcn(app)
            
            app.CohesionLIN.Value=0;
            app.CohesionLINmin.Value=0;
            app.CohesionLINmax.Value=0;
            app.TensStrLIN.Value=0;
            app.TensStrLINmin.Value=0;
            app.TensStrLINmax.Value=0;
            
            plot(app.UIAxes,0,0)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 995 664];
            app.UIFigure.Name = 'MATLAB App';

            % Create GridLayout
            app.GridLayout = uigridlayout(app.UIFigure);
            app.GridLayout.ColumnWidth = {'1x', 125.99, '1x', '0.5x', 656.99};
            app.GridLayout.RowHeight = {371, 115, 25, 25, 25, 25};

            % Create InputdataPanel
            app.InputdataPanel = uipanel(app.GridLayout);
            app.InputdataPanel.Title = 'Input data';
            app.InputdataPanel.Layout.Row = [1 2];
            app.InputdataPanel.Layout.Column = [1 3];
            app.InputdataPanel.FontWeight = 'bold';

            % Create UITable
            app.UITable = uitable(app.InputdataPanel);
            app.UITable.ColumnName = {'Sigma (Pa)'; 'Tau (Pa)'};
            app.UITable.RowName = {};
            app.UITable.ColumnSortable = true;
            app.UITable.ColumnEditable = true;
            app.UITable.ForegroundColor = [0.149 0.149 0.149];
            app.UITable.Position = [34 129 200 308];

            % Create ShearDataLabel
            app.ShearDataLabel = uilabel(app.InputdataPanel);
            app.ShearDataLabel.BackgroundColor = [0.651 0.651 0.651];
            app.ShearDataLabel.HorizontalAlignment = 'center';
            app.ShearDataLabel.FontWeight = 'bold';
            app.ShearDataLabel.Position = [34 440 200 23];
            app.ShearDataLabel.Text = 'Shear Data';

            % Create PreShearLABEL
            app.PreShearLABEL = uilabel(app.InputdataPanel);
            app.PreShearLABEL.BackgroundColor = [0.651 0.651 0.651];
            app.PreShearLABEL.HorizontalAlignment = 'center';
            app.PreShearLABEL.FontWeight = 'bold';
            app.PreShearLABEL.Position = [34 92 200 22];
            app.PreShearLABEL.Text = 'Pre-Shear Data';

            % Create SigmaPreShEditFieldLabel
            app.SigmaPreShEditFieldLabel = uilabel(app.InputdataPanel);
            app.SigmaPreShEditFieldLabel.Position = [34 56 80 22];
            app.SigmaPreShEditFieldLabel.Text = 'Sigma Pre-Sh';

            % Create SigmaPre
            app.SigmaPre = uieditfield(app.InputdataPanel, 'numeric');
            app.SigmaPre.Position = [128 56 66 22];

            % Create TauPreShEditFieldLabel
            app.TauPreShEditFieldLabel = uilabel(app.InputdataPanel);
            app.TauPreShEditFieldLabel.Position = [34 24 66 22];
            app.TauPreShEditFieldLabel.Text = 'Tau Pre-Sh';

            % Create TauPre
            app.TauPre = uieditfield(app.InputdataPanel, 'numeric');
            app.TauPre.Position = [127 24 67 22];

            % Create Button
            app.Button = uibutton(app.InputdataPanel, 'push');
            app.Button.ButtonPushedFcn = createCallbackFcn(app, @ButtonPushed, true);
            app.Button.IconAlignment = 'top';
            app.Button.FontSize = 18;
            app.Button.FontWeight = 'bold';
            app.Button.Position = [237 381 28 28];
            app.Button.Text = '+';

            % Create Button_2
            app.Button_2 = uibutton(app.InputdataPanel, 'push');
            app.Button_2.ButtonPushedFcn = createCallbackFcn(app, @Button_2Pushed, true);
            app.Button_2.IconAlignment = 'top';
            app.Button_2.FontSize = 18;
            app.Button_2.FontWeight = 'bold';
            app.Button_2.Position = [237 348 28 28];
            app.Button_2.Text = '-';

            % Create LINEARYLButton
            app.LINEARYLButton = uibutton(app.GridLayout, 'push');
            app.LINEARYLButton.ButtonPushedFcn = createCallbackFcn(app, @LINEARYLButtonPushed, true);
            app.LINEARYLButton.BackgroundColor = [0.9882 0.3647 0.3647];
            app.LINEARYLButton.FontWeight = 'bold';
            app.LINEARYLButton.Layout.Row = 3;
            app.LINEARYLButton.Layout.Column = 2;
            app.LINEARYLButton.Text = 'LINEAR YL';

            % Create WARRENSPRINGButton
            app.WARRENSPRINGButton = uibutton(app.GridLayout, 'push');
            app.WARRENSPRINGButton.ButtonPushedFcn = createCallbackFcn(app, @WARRENSPRINGButtonPushed, true);
            app.WARRENSPRINGButton.BackgroundColor = [0.0745 0.6235 1];
            app.WARRENSPRINGButton.FontWeight = 'bold';
            app.WARRENSPRINGButton.Layout.Row = 4;
            app.WARRENSPRINGButton.Layout.Column = 2;
            app.WARRENSPRINGButton.Text = 'WARREN-SPRING';

            % Create COMPAREButton
            app.COMPAREButton = uibutton(app.GridLayout, 'push');
            app.COMPAREButton.ButtonPushedFcn = createCallbackFcn(app, @COMPAREButtonPushed, true);
            app.COMPAREButton.BackgroundColor = [0.149 0.149 0.149];
            app.COMPAREButton.FontWeight = 'bold';
            app.COMPAREButton.FontColor = [1 1 1];
            app.COMPAREButton.Layout.Row = 5;
            app.COMPAREButton.Layout.Column = 2;
            app.COMPAREButton.Text = 'COMPARE';

            % Create DiagramPanel
            app.DiagramPanel = uipanel(app.GridLayout);
            app.DiagramPanel.Title = 'Diagram';
            app.DiagramPanel.Layout.Row = 1;
            app.DiagramPanel.Layout.Column = 5;
            app.DiagramPanel.FontWeight = 'bold';

            % Create UIAxes
            app.UIAxes = uiaxes(app.DiagramPanel);
            title(app.UIAxes, 'Yield Locus')
            xlabel(app.UIAxes, 'Sigma (Pa)')
            ylabel(app.UIAxes, 'Tau (Pa)')
            app.UIAxes.Position = [19 21 613 316];

            % Create OutputDataPanel
            app.OutputDataPanel = uipanel(app.GridLayout);
            app.OutputDataPanel.Title = 'Output Data';
            app.OutputDataPanel.Layout.Row = [2 6];
            app.OutputDataPanel.Layout.Column = 5;
            app.OutputDataPanel.FontWeight = 'bold';

            % Create UITable2
            app.UITable2 = uitable(app.OutputDataPanel);
            app.UITable2.ColumnName = {'Linear YL'; 'WS YL'};
            app.UITable2.ColumnWidth = {72, 72};
            app.UITable2.RowName = {'Sigma1 (Pa) '; 'R (Pa)'; 'M (Pa)'; 'fc (Pa)'; 'C (Pa)'; 'Tensile Strenght (Pa)'; 'n (-)'; 'Phi (deg)'};
            app.UITable2.Position = [19 14 275 206];

            % Create TabGroup
            app.TabGroup = uitabgroup(app.OutputDataPanel);
            app.TabGroup.Position = [333 15 299 218];

            % Create ModelfittingTab
            app.ModelfittingTab = uitab(app.TabGroup);
            app.ModelfittingTab.Title = 'Model fitting ';

            % Create UITable3
            app.UITable3 = uitable(app.ModelfittingTab);
            app.UITable3.ColumnName = {'Linear YL'; 'WS YL'};
            app.UITable3.RowName = {'R-Squared'; 'RMSE'; 'Person''s R'};
            app.UITable3.Position = [1 15 295 178];

            % Create ParametersdataTab
            app.ParametersdataTab = uitab(app.TabGroup);
            app.ParametersdataTab.Title = 'Parameters data';

            % Create CohesionPaEditFieldLabel
            app.CohesionPaEditFieldLabel = uilabel(app.ParametersdataTab);
            app.CohesionPaEditFieldLabel.Position = [3 128 82 23];
            app.CohesionPaEditFieldLabel.Text = 'Cohesion (Pa)';

            % Create CohesionLIN
            app.CohesionLIN = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionLIN.Position = [99 129 64 22];

            % Create CohesionLINmin
            app.CohesionLINmin = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionLINmin.Position = [164 129 64 22];

            % Create CohesionLINmax
            app.CohesionLINmax = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionLINmax.Position = [230 129 64 22];

            % Create TensStrPaEditFieldLabel
            app.TensStrPaEditFieldLabel = uilabel(app.ParametersdataTab);
            app.TensStrPaEditFieldLabel.Position = [3 98 82 23];
            app.TensStrPaEditFieldLabel.Text = 'Tens. Str. (Pa)';

            % Create TensStrLIN
            app.TensStrLIN = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrLIN.Position = [99 99 64 22];

            % Create TensStrLINmin
            app.TensStrLINmin = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrLINmin.Position = [164 99 64 22];

            % Create TensStrLINmax
            app.TensStrLINmax = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrLINmax.Position = [230 99 64 22];

            % Create CohesionPaEditField_2Label
            app.CohesionPaEditField_2Label = uilabel(app.ParametersdataTab);
            app.CohesionPaEditField_2Label.Position = [4 35 82 23];
            app.CohesionPaEditField_2Label.Text = 'Cohesion (Pa)';

            % Create CohesionWS
            app.CohesionWS = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionWS.Position = [100 36 64 22];

            % Create CohesionWSmin
            app.CohesionWSmin = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionWSmin.Position = [165 36 64 22];

            % Create CohesionWSmax
            app.CohesionWSmax = uieditfield(app.ParametersdataTab, 'numeric');
            app.CohesionWSmax.Position = [231 36 64 22];

            % Create TensStrPaEditField_2Label
            app.TensStrPaEditField_2Label = uilabel(app.ParametersdataTab);
            app.TensStrPaEditField_2Label.Position = [4 5 82 23];
            app.TensStrPaEditField_2Label.Text = 'Tens. Str. (Pa)';

            % Create TensStrWS
            app.TensStrWS = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrWS.Position = [100 6 64 22];

            % Create TensStrWSmin
            app.TensStrWSmin = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrWSmin.Position = [165 6 64 22];

            % Create TensStrWSmax
            app.TensStrWSmax = uieditfield(app.ParametersdataTab, 'numeric');
            app.TensStrWSmax.Position = [231 6 64 22];

            % Create LinearYLLabel
            app.LinearYLLabel = uilabel(app.ParametersdataTab);
            app.LinearYLLabel.BackgroundColor = [0.902 0.902 0.902];
            app.LinearYLLabel.FontWeight = 'bold';
            app.LinearYLLabel.Position = [4 159 60 23];
            app.LinearYLLabel.Text = 'Linear YL';

            % Create WarrenSpringYLLabel
            app.WarrenSpringYLLabel = uilabel(app.ParametersdataTab);
            app.WarrenSpringYLLabel.BackgroundColor = [0.902 0.902 0.902];
            app.WarrenSpringYLLabel.FontWeight = 'bold';
            app.WarrenSpringYLLabel.Position = [4 65 107 23];
            app.WarrenSpringYLLabel.Text = 'Warren-Spring YL';

            % Create ValueLabel
            app.ValueLabel = uilabel(app.ParametersdataTab);
            app.ValueLabel.BackgroundColor = [1 1 1];
            app.ValueLabel.HorizontalAlignment = 'center';
            app.ValueLabel.FontWeight = 'bold';
            app.ValueLabel.Position = [100 159 63 23];
            app.ValueLabel.Text = 'Value';

            % Create MinLabel
            app.MinLabel = uilabel(app.ParametersdataTab);
            app.MinLabel.BackgroundColor = [1 1 1];
            app.MinLabel.HorizontalAlignment = 'center';
            app.MinLabel.FontWeight = 'bold';
            app.MinLabel.Position = [166 159 62 23];
            app.MinLabel.Text = 'Min';

            % Create MaxLabel
            app.MaxLabel = uilabel(app.ParametersdataTab);
            app.MaxLabel.BackgroundColor = [1 1 1];
            app.MaxLabel.HorizontalAlignment = 'center';
            app.MaxLabel.FontWeight = 'bold';
            app.MaxLabel.Position = [231 159 62 23];
            app.MaxLabel.Text = 'Max';

            % Create RESETRESULTSButton
            app.RESETRESULTSButton = uibutton(app.GridLayout, 'push');
            app.RESETRESULTSButton.ButtonPushedFcn = createCallbackFcn(app, @RESETRESULTSButtonPushed, true);
            app.RESETRESULTSButton.BackgroundColor = [1 1 1];
            app.RESETRESULTSButton.FontWeight = 'bold';
            app.RESETRESULTSButton.Layout.Row = 6;
            app.RESETRESULTSButton.Layout.Column = 2;
            app.RESETRESULTSButton.Text = 'RESET RESULTS';

            % Create REBOOTButton
            app.REBOOTButton = uibutton(app.GridLayout, 'push');
            app.REBOOTButton.ButtonPushedFcn = createCallbackFcn(app, @REBOOTButtonPushed, true);
            app.REBOOTButton.BackgroundColor = [1 1 1];
            app.REBOOTButton.FontSize = 10;
            app.REBOOTButton.FontWeight = 'bold';
            app.REBOOTButton.Layout.Row = 6;
            app.REBOOTButton.Layout.Column = 3;
            app.REBOOTButton.Text = 'REBOOT';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = app2

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end